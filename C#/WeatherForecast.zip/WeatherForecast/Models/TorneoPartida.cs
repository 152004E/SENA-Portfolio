
namespace ChessProject.Models
{
    public class TorneoPartida
    {
        public int TorneoId { get; set; }
        public int PartidaId { get; set; }
        public int Ronda { get; set; }
    }
}

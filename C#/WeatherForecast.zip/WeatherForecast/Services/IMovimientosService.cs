﻿using ChessProject.Models;

namespace WebApplicationConDB.Services
{
    public interface IMovimientosService
    {
        List<Movimiento> GetMovimientos();
        void Create(Movimiento movimiento);
        Movimiento GetById(int Id);
        Movimiento Update(int id, Movimiento movimiento);
        void Delete(int id);
    }
}

﻿using ChessProject.Models;
using WebApplicationConDB.Data;

namespace WebApplicationConDB.Services
{
    public class MovimientoService : IMovimientosService
    {

        private readonly AppDbContext _context;


        public MovimientoService(AppDbContext context)
        {
            _context = context;
        }

        //Listar
        public List<Movimiento> GetMovimientos()
        {
            var movimiento = _context.Movimientos.ToList();
            return movimiento;
        }

        //Crear
        public void Create(Movimiento movimiento)
        {
            _context.Movimientos.Add(movimiento);
            _context.SaveChanges();
        }

        //Actualizar
        public Movimiento Update(int id, Movimiento movimiento)
        {
            var movimientoAct = _context.Movimientos.Find(id);

            if (movimientoAct == null)
            {
                Console.WriteLine($"No se encontró el jugador con el id {id}");

            }
            else
            {
                movimientoAct.PartidaId = movimiento.PartidaId;
                movimientoAct.NumeroTurno = movimiento.NumeroTurno;
                movimientoAct.Color = movimiento.Color;
                movimientoAct.Notacion = movimiento.Notacion;
                movimientoAct.Origen = movimiento.Origen;
                movimientoAct.Destino = movimiento.Destino;
                movimientoAct.Pieza = movimiento.Pieza;
                movimientoAct.PiezaCapturada = movimiento.PiezaCapturada;

                _context.SaveChanges();

            }


            return movimientoAct;
        }

        //Eliminar
        public void Delete(int id)
        {
            var movimientoEliminar = _context.Movimientos.FirstOrDefault(j => j.MovimientoId == id);

            if (movimientoEliminar != null)
            {
                _context.Movimientos.Remove(movimientoEliminar);
                _context.SaveChanges();
            }
        }

        //Buscar  movimiento por id
        public Movimiento GetById(int Id)
        {
            return _context.Movimientos
                .Where(j => j.MovimientoId == Id)
                .FirstOrDefault();
        }



    }
}